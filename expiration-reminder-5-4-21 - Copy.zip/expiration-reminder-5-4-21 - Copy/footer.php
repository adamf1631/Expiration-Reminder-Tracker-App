  <!DOCTYPE html>
  <html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <title></title>
    </head>
    <body>
      <footer> &copy; All Rights Reserved | <?php echo date('M Y'); ?></footer>
  </div>
  <!-- Copyright -->
    </body>
  </html>
